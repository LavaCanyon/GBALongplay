"""GBA Longplay reference encoder."""
